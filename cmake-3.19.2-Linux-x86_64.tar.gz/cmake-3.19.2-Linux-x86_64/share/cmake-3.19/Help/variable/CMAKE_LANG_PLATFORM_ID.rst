CMAKE_<LANG>_PLATFORM_ID
------------------------

An internal variable subject to change.

This is used in determining the platform and is subject to change.
