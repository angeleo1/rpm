CMAKE_COMMAND
-------------

The full path to the :manual:`cmake(1)` executable.

This is the full path to the CMake executable :manual:`cmake(1)` which is
useful from custom commands that want to use the ``cmake -E`` option for
portable system commands.  (e.g.  ``/usr/local/bin/cmake``)
