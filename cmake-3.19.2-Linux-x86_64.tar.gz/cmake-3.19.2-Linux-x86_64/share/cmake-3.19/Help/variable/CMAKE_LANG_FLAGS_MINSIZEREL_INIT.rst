CMAKE_<LANG>_FLAGS_MINSIZEREL_INIT
----------------------------------

.. versionadded:: 3.7

This variable is the ``MinSizeRel`` variant of the
:variable:`CMAKE_<LANG>_FLAGS_<CONFIG>_INIT` variable.
