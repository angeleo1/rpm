CMAKE_PCH_WARN_INVALID
----------------------

.. versionadded:: 3.18

This variable is used to initialize the :prop_tgt:`PCH_WARN_INVALID`
property of targets when they are created.
