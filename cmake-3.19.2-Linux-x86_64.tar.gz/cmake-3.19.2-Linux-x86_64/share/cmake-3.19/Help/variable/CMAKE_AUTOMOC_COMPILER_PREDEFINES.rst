CMAKE_AUTOMOC_COMPILER_PREDEFINES
---------------------------------

.. versionadded:: 3.10

This variable is used to initialize the :prop_tgt:`AUTOMOC_COMPILER_PREDEFINES`
property on all the targets. See that target property for additional
information.

By default it is ON.
