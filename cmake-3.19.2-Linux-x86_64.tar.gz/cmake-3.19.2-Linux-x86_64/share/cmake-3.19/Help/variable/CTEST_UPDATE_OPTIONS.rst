CTEST_UPDATE_OPTIONS
--------------------

.. versionadded:: 3.1

Specify the CTest ``UpdateOptions`` setting
in a :manual:`ctest(1)` dashboard client script.
