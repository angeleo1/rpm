CMAKE_<LANG>_FLAGS_<CONFIG>
---------------------------

.. versionadded:: 3.11

Flags for language ``<LANG>`` when building for the ``<CONFIG>`` configuration.
