<?php

/**
 * @since 1.20
 */
class TimestampException extends MWException {
}
